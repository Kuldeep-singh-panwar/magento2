define([
    'jquery',
    'mage/translate'
], function ($) {
    'use strict';

    $.widget('custom.tabs', {
        options: {
            activeTab: 'info'
        },

        /** @inheritdoc */
        _create: function () {
            this.tabButtons = this.element.find('.tab');
            this.tabContents = this.element.find('.tab-content');
            
            this._bindEvents();
            this._activateTab(this.options.activeTab);
        },

        /** @inheritdoc */
        _bindEvents: function () {
            var self = this;
            
            this.tabButtons.on('click', function () {
                var tabName = $(this).data('tab');
                self._activateTab(tabName);
            });
        },

        /**
         * Activate tab
         * @param {String} tabName
         * @private
         */
        _activateTab: function (tabName) {
            // Update button states
            this.tabButtons.removeClass('active');
            this.element.find('.tab[data-tab="' + tabName + '"]').addClass('active');
            
            // Update content visibility
            this.tabContents.removeClass('active');
            
            if (tabName === 'info') {
                $('#infoContent').addClass('active');
            } else {
                $('#productsContent').addClass('active');
            }
        }
    });

    return $.custom.tabs;
});