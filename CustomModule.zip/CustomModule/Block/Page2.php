<?php
namespace YourCompany\CustomModule\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class Page2 extends Template
{
    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * Get page information
     */
    public function getPageInfo()
    {
        return [
            'title' => 'Additional Information',
            'description' => 'Welcome to the second page with detailed module information.',
            'stats' => [
                ['number' => '500+', 'label' => 'Happy Clients'],
                ['number' => '1000+', 'label' => 'Projects Completed'],
                ['number' => '24/7', 'label' => 'Support Available']
            ]
        ];
    }
}