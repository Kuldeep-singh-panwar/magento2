<?php
namespace Testing\CustomModule\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class Page1 extends Template
{
    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    public function getInfoLinks()
    {
        return [
            [
                'title' => 'Getting Started Guide',
                'url' => $this->getUrl('custommodule/page1/guide'),
                'icon' => '🚀',
                'description' => 'Learn the basics and setup your account in minutes.'
            ],
            [
                'title' => 'Advanced Features',
                'url' => $this->getUrl('custommodule/page1/features'),
                'icon' => '⚡',
                'description' => 'Discover pro tips and advanced settings.'
            ]
        ];
    }

    public function getProducts()
    {
        return [
            [
                'name' => 'Laptop Pro',
                'price' => '$999',
                'icon' => '💻',
                'description' => 'High-performance laptop'
            ],
            [
                'name' => 'SmartPhone X',
                'price' => '$699',
                'icon' => '📱',
                'description' => 'Latest smartphone'
            ],
            [
                'name' => 'Wireless Headphones',
                'price' => '$199',
                'icon' => '🎧',
                'description' => 'Noise cancelling'
            ]
        ];
    }
}