<?php
class Tesing_CustomDashboard_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function settingAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function productsAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function infoAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }
    
    public function saveRegistrationAction()
    {
        if ($data = $this->getRequest()->getPost()) {
            try {
                $customer = Mage::getModel('customer/customer')
                    ->setFirstname($data['firstname'])
                    ->setLastname($data['lastname'])
                    ->setEmail($data['email'])
                    ->setPassword($data['password']);
                
                $customer->save();
                
                Mage::getSingleton('core/session')->addSuccess('Registration successful!');
                $this->_redirect('dashboard/index/setting');
            } catch (Exception $e) {
                Mage::getSingleton('core/session')->addError($e->getMessage());
                $this->_redirect('dashboard/index/setting');
            }
        }
    }
}