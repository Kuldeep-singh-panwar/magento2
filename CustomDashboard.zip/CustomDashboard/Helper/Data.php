<?php
class Tesing_CustomDashboard_Helper_Data extends Mage_Core_Helper_Abstract
{
}