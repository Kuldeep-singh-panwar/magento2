<?php
class Tesing_CustomDashboard_Block_Dashboard extends Mage_Core_Block_Template
{
    public function getActiveMenu()
    {
        return $this->getRequest()->getActionName();
    }
    
    public function getProducts()
    {
        $products = Mage::getModel('catalog/product')
            ->getCollection()
            ->addAttributeToSelect('*')
            ->addAttributeToFilter('status', 1)
            ->addAttributeToFilter('visibility', array('in' => array(
                Mage_Catalog_Model_Product_Visibility::VISIBILITY_BOTH,
                Mage_Catalog_Model_Product_Visibility::VISIBILITY_IN_CATALOG
            )))
            ->setPageSize(12);
        return $products;
    }
    
    public function getProductImageUrl($product)
    {
        return (string)Mage::helper('catalog/image')->init($product, 'small_image')->resize(135, 135);
    }
    
    public function getAddToCartUrl($product)
    {
        return Mage::helper('checkout/cart')->getAddUrl($product);
    }
}